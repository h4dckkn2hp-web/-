#!/usr/bin/env node
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { OpenAI } = require('openai');

const UPLOAD_DIR = path.resolve('/home/user/workspace/upload');
const QUEUE_CSV = path.resolve(__dirname, '../data/queue.csv');
const TOPICS_JSON = path.resolve(__dirname, '../data/topics.json');

function pickImages(limit=6){
  if (!fs.existsSync(UPLOAD_DIR)) return [];
  const files = fs.readdirSync(UPLOAD_DIR).filter(f => /\.(jpg|jpeg|png|webp)$/i.test(f)).slice(0, limit);
  return files.join(';');
}

async function generateCopy(prompt){
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const sys = '你是资深小红书内容运营编辑，擅长生成具有吸引力的标题、正文与合规的话题标签。输出时用JSON，包含title, body, tags（逗号分隔）。';
  const user = `请为以下主题生成一条小红书图文：\n主题：${prompt}\n要求：\n- 标题不超过30字，包含一个强烈钩子\n- 正文200-400字，包含3-5个要点，自然口吻\n- 话题标签5-8个，贴近内容且合规`;
  const res = await client.chat.completions.create({
    model: 'gpt-4.1-mini',
    messages: [
      { role: 'system', content: sys },
      { role: 'user', content: user }
    ],
    temperature: 0.7
  });
  const text = res.choices[0].message.content;
  let data;
  try { data = JSON.parse(text); } catch {
    // fallback: naive parse
    data = { title: prompt, body: text, tags: '小红书,分享' };
  }
  return data;
}

function appendCSVRow({title, body, tags, images}){
  const header = 'title,body,tags,images\n';
  if (!fs.existsSync(QUEUE_CSV) || fs.readFileSync(QUEUE_CSV,'utf-8').trim().length===0){
    fs.writeFileSync(QUEUE_CSV, header, 'utf-8');
  }
  const esc = s => '"' + String(s).replace(/"/g,'""') + '"';
  const line = [esc(title), esc(body), esc(tags), esc(images)].join(',')+'\n';
  fs.appendFileSync(QUEUE_CSV, line, 'utf-8');
}

async function main(){
  const topics = JSON.parse(fs.readFileSync(TOPICS_JSON,'utf-8'));
  if (!Array.isArray(topics) || topics.length===0){
    console.error('请在 data/topics.json 中填入主题数组，例如 ["护肤心得","旅行攻略"]');
    process.exit(1);
  }
  for (const t of topics){
    const copy = await generateCopy(t);
    const images = pickImages(6);
    appendCSVRow({ title: copy.title, body: copy.body, tags: copy.tags, images });
    console.log('生成完成:', copy.title);
  }
}

if (require.main === module){
  main().catch(e=>{ console.error(e); process.exit(1); });
}
