#!/usr/bin/env node
const { spawn } = require('child_process');
const path = require('path');

function run(cmd, args, opts={}){
  return new Promise((resolve,reject)=>{
    const p = spawn(cmd, args, { stdio: 'inherit', ...opts });
    p.on('exit', code => code===0?resolve():reject(new Error(`${cmd} exited ${code}`)));
  });
}

async function main(){
  const action = process.argv[2] || 'help';
  switch(action){
    case 'generate':
      await run('node', [path.resolve(__dirname,'generator.js')]);
      break;
    case 'publish':
      await run('node', [path.resolve(__dirname,'publisher.js')]);
      break;
    case 'help':
    default:
      console.log('用法:');
      console.log('  node src/cli.js generate   # 根据 data/topics.json 生成文案并写入 data/queue.csv');
      console.log('  node src/cli.js publish    # 读取 data/queue.csv，使用Playwright自动发布');
      console.log('\n准备工作:');
      console.log('  1) 在 /home/user/workspace/upload 放入图片文件（jpg/png）');
      console.log('  2) 在 /home/user/workspace/upload 放入 cookies.json（登录小红书创作者中心后导出）');
      console.log('  3) 在 .env 填写 OPENAI_API_KEY');
      break;
  }
}

if (require.main === module){
  main().catch(e=>{ console.error(e); process.exit(1); });
}
