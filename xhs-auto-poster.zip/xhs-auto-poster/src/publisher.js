#!/usr/bin/env node
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse');
const { chromium } = require('playwright');
const axios = require('axios');

// Config
const UPLOAD_DIR = path.resolve('/home/user/workspace/upload');
const QUEUE_CSV = path.resolve(__dirname, '../data/queue.csv');
const COOKIES_PATH = path.resolve(UPLOAD_DIR, 'cookies.json');
const CREATOR_URL = process.env.XHS_CREATOR_URL || 'https://creator.xiaohongshu.com';

// Helpers
function readCSVQueue(filePath) {
  return new Promise((resolve, reject) => {
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(parse({ columns: true, skip_empty_lines: true }))
      .on('data', r => rows.push(r))
      .on('error', reject)
      .on('end', () => resolve(rows));
  });
}

function resolveImages(imagesField) {
  if (!imagesField) return [];
  // images field can be semicolon-separated relative filenames under /upload
  return imagesField.split(/[;,\s]+/).filter(Boolean).map(p => path.resolve(UPLOAD_DIR, p));
}

async function loadCookies(context) {
  if (!fs.existsSync(COOKIES_PATH)) {
    throw new Error(`Cookies file not found: ${COOKIES_PATH}. 请在本地登录小红书创作者中心后导出cookies.json到/upload目录`);
  }
  const cookies = JSON.parse(fs.readFileSync(COOKIES_PATH, 'utf-8'));
  await context.addCookies(cookies);
}

async function ensureLoggedIn(page) {
  await page.goto(CREATOR_URL, { waitUntil: 'domcontentloaded' });
  // Basic check: presence of user avatar or upload button
  const loggedIn = await page.locator('text=创作服务平台').count().catch(() => 0);
  // Regardless of check, attempt to navigate to note publish page
  await page.goto(`${CREATOR_URL}/publish`, { waitUntil: 'load' }).catch(()=>{});
}

async function uploadImages(page, imagePaths) {
  // Try to find input[type=file]
  const input = page.locator('input[type="file"]');
  const count = await input.count();
  if (count === 0) {
    // fallback: open upload dialog via button text
    const buttonTexts = ['上传图片', '选择图片', '添加图片', '本地上传'];
    for (const t of buttonTexts) {
      const btn = page.getByText(t, { exact: false });
      if (await btn.count()) {
        await btn.first().click();
        break;
      }
    }
  }
  // re-query file input
  const fileInput = page.locator('input[type="file"]');
  if (await fileInput.count()) {
    await fileInput.setInputFiles(imagePaths.map(p => ({ name: path.basename(p), mimeType: 'image/jpeg', buffer: fs.readFileSync(p) })));
  } else {
    console.warn('未找到文件选择器，可能需要人工介入一次以定位上传组件');
  }
}

async function fillText(page, title, body, tags) {
  const titleCandidates = ['标题', '笔记标题', '输入标题'];
  for (const t of titleCandidates) {
    const titleBox = page.getByPlaceholder(t);
    if (await titleBox.count()) {
      await titleBox.fill(title);
      break;
    }
  }
  const bodyCandidates = ['请输入正文', '正文', '内容', '描述'];
  for (const t of bodyCandidates) {
    const bodyBox = page.getByPlaceholder(t);
    if (await bodyBox.count()) {
      await bodyBox.fill(body);
      break;
    }
  }
  if (tags && tags.length) {
    const tagInputCandidates = ['输入话题', '添加话题', '#话题'];
    for (const t of tagInputCandidates) {
      const tagBox = page.getByPlaceholder(t);
      if (await tagBox.count()) {
        for (const tag of tags) {
          await tagBox.fill(tag);
          await page.keyboard.press('Enter');
        }
        break;
      }
    }
  }
}

async function clickPublish(page) {
  const publishTexts = ['发布', '立即发布', '提交', '保存并发布'];
  for (const t of publishTexts) {
    const btn = page.getByText(t, { exact: false });
    if (await btn.count()) {
      await btn.first().click();
      return;
    }
  }
  console.warn('未找到发布按钮，可能需要更新选择器');
}

async function runOne(context, job) {
  const page = await context.newPage();
  await ensureLoggedIn(page);
  const images = resolveImages(job.images);
  const tags = (job.tags || '').split(/[#,;\s]+/).filter(Boolean).slice(0, 5);
  await uploadImages(page, images);
  await fillText(page, job.title || '无标题', job.body || '', tags);
  await clickPublish(page);
  await page.waitForTimeout(3000);
  await page.close();
}

async function main() {
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  await loadCookies(context);
  const queue = await readCSVQueue(QUEUE_CSV);
  for (const job of queue) {
    console.log('Publishing:', job.title);
    try {
      await runOne(context, job);
    } catch (e) {
      console.error('Failed to publish job:', job.title, e.message);
    }
  }
  await browser.close();
}

if (require.main === module) {
  main().catch(err => { console.error(err); process.exit(1); });
}
